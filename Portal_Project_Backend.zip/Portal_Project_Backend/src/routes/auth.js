const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/Users');

const router = express.Router();

// User Login Route (Handles both Admin & Users)
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        // Check if user exists
        const user = await User.findOne({ email });
        if (!user) return res.status(400).json({ message: "Invalid Credentials" });

        // Compare hashed password
        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) return res.status(400).json({ message: "Invalid Credentials" });

        // Generate JWT token
        const token = jwt.sign(
            { id: user._id, roles: user.roles },  // Include roles in token
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        );

        // Update last login time
        user.last_login = new Date();
        await user.save();

        res.json({ token, message: "Login successful", roles: user.roles });

    } catch (error) {
        res.status(500).json({ message: "Server Error" });
    }
});

module.exports = router;
