// src/routes/admin.js
const express = require('express');
const { auth, adminOnly } = require('../middleware/auth');  // Updated import to match exports
const router = express.Router();

// Access Profile Approval Section (Admin Only)
router.get('/profile-approval', auth, adminOnly, (req, res) => {
    res.json({ message: "Welcome to the Profile Approval Section, Admin" });
});

module.exports = router;